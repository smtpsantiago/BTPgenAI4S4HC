sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("josebecerra07a19.ProductFAQApp.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);