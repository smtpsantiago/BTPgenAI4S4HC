sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("josebecerra07a19.Customermessages.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map