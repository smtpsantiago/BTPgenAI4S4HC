sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("josebecerra04a19.Customermessage.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map